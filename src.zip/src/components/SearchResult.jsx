import { useLocation, useNavigate } from "react-router-dom";

import surprise from "../assets/surprise.png";

import axios from "axios";
import { useEffect, useState } from "react";

import { X, Shuffle, Heart, ChefHat } from "lucide-react";

import { Defaultrecipes } from "./Defaultrecipes";
import { AsideNavbar } from "./AsideNavbar";
import { HeaderDashboard } from "./HeaderDashboard";
import { RandomRecipe } from "./RandomRecipe";

export const SearchResult = ({ isLoggedIn, setIsLoggedIn }) => {
  const location = useLocation();
  const navigate = useNavigate();

  const [recipes, setRecipes] = useState([]);
  const [recipe, setRecipe] = useState(null);
  const [error, setError] = useState(null);
  const [random, setRandom] = useState(null);

  const [newSearch, setNewSearch] = useState("");
  const [searchQuery, setSearchQuery] = useState("");

  const [defaultRecipes, setDefaultRecipes] = useState({});
  const [name, setName] = useState(null);

  const query = location.state?.query;

  // --------------------------------------------------
  // Initial search
  // --------------------------------------------------

  useEffect(() => {
    if (!query) {
      return;
    }

    async function fetchRecipies() {
      try {
        const response = await axios.get(
          `https://www.themealdb.com/api/json/v1/1/search.php?s=${query}`,
        );

        const recipies = response.data.meals || [];

        setRecipes(recipies);
        setError("");
      } catch (error) {
        console.log(error);
        setError("Something went wrong");
      }
    }

    fetchRecipies();
  }, [query]);

  // --------------------------------------------------
  // New search
  // --------------------------------------------------

  useEffect(() => {
    if (!searchQuery.trim()) {
      return;
    }

    async function fetchNewRecipies() {
      try {
        setRandom(null);
        setDefaultRecipes({});

        const response = await axios.get(
          `https://www.themealdb.com/api/json/v1/1/search.php?s=${searchQuery}`,
        );

        const recipies = response.data.meals || [];

        if (recipies.length === 0) {
          setError("No recipe found");
          setRecipes([]);
        } else {
          setError("");
          setRecipes(recipies);
        }
      } catch (error) {
        console.log(error);
        setError("Something went wrong");
      }
    }

    fetchNewRecipies();
  }, [searchQuery]);

  // --------------------------------------------------
  // Random recipe
  // --------------------------------------------------

  async function handleRandom() {
    try {
      setDefaultRecipes({});

      const response = await axios.get(
        "https://www.themealdb.com/api/json/v1/1/random.php",
      );

      setRandom(response.data.meals[0]);
    } catch (error) {
      console.log(error);
    }
  }

  // --------------------------------------------------
  // Save recipe
  // --------------------------------------------------

  function saveRecipe(recipeToSave) {
    const currentUser = JSON.parse(
      localStorage.getItem("recipeBoxCurrentUser"),
    );

    if (!currentUser) {
      sessionStorage.setItem("pendingRecipe", JSON.stringify(recipeToSave));

      navigate("/login");

      return;
    }

    const users = JSON.parse(localStorage.getItem("recipeBoxUsers")) || [];

    const loggedUser = users.find((user) => user.id === currentUser);

    if (!loggedUser) {
      sessionStorage.setItem("pendingRecipe", JSON.stringify(recipeToSave));

      navigate("/login");

      return;
    }

    loggedUser.recipies = loggedUser.recipies || [];

    const existingRecipe = loggedUser.recipies.find(
      (recipe) => recipe.idMeal === recipeToSave.idMeal,
    );

    if (existingRecipe) {
      console.log("Recipe already exists");
      return;
    }

    loggedUser.recipies.push(recipeToSave);

    localStorage.setItem("recipeBoxUsers", JSON.stringify(users));

    console.log("Recipe saved successfully");
  }

  // --------------------------------------------------
  // Get logged user
  // --------------------------------------------------

  useEffect(() => {
    const response = JSON.parse(localStorage.getItem("recipeBoxUsers")) || [];

    const currentUser = JSON.parse(
      localStorage.getItem("recipeBoxCurrentUser"),
    );

    const loggedUser = response.find((user) => user.id === currentUser);

    if (loggedUser) {
      setName(loggedUser.name[0]);
    }
  }, []);

  // --------------------------------------------------
  // Default recipes
  // --------------------------------------------------

  const defaultDishes = ["chicken", "rice", "beef"];

  useEffect(() => {
    async function fetchDefaultRecipes() {
      try {
        const responses = await Promise.all(
          defaultDishes.map(async (dish) => {
            const response = await axios.get(
              `https://www.themealdb.com/api/json/v1/1/filter.php?i=${dish}`,
            );

            return {
              dish,
              recipes: response.data.meals || [],
            };
          }),
        );

        const recipesObject = {};

        responses.forEach(({ dish, recipes }) => {
          recipesObject[dish] = recipes;
        });

        setDefaultRecipes(recipesObject);
      } catch (error) {
        console.log(error);
      }
    }

    fetchDefaultRecipes();
  }, []);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* ---------------------------------------------
          Main Layout
      --------------------------------------------- */}

      <div className="flex min-h-screen">
        {/* Sidebar */}

        <AsideNavbar isLoggedIn={isLoggedIn} setIsLoggedIn={setIsLoggedIn} />

        {/* Main Content */}

        <main
          className="
            min-h-screen
            w-full
            overflow-y-auto
            lg:ml-0
            lg:w-[calc(100%-250px)]
          "
        >
          {/* Dashboard Header */}

          <HeaderDashboard
            newSearch={newSearch}
            setNewSearch={setNewSearch}
            setSearchQuery={setSearchQuery}
            name={name}
            isLoggedIn={isLoggedIn}
          />

          {/* ---------------------------------------------
              Surprise Me Banner
          --------------------------------------------- */}

          <section className="relative mx-3 mt-4 overflow-hidden rounded-2xl sm:mx-5 md:mx-6">
            <img
              src={surprise}
              alt="Surprise recipe"
              className="
                h-40
                w-full
                object-cover
                sm:h-48
                md:h-56
                lg:h-64
              "
            />

            {/* Dark overlay */}

            <div className="absolute inset-0 bg-black/10" />

            {/* Surprise Button */}

            <button
              onClick={handleRandom}
              className="
                absolute
                bottom-4
                right-4

                flex
                items-center
                gap-2

                rounded-full
                bg-orange-700
                px-4
                py-2

                text-sm
                font-bold
                text-white

                shadow-xl
                transition

                hover:scale-105
                hover:bg-orange-800

                sm:bottom-6
                sm:right-6
                sm:px-5
                sm:py-2.5
                sm:text-base
              "
            >
              <Shuffle className="size-4 sm:size-5" />

              <span>Surprise Me</span>
            </button>
          </section>

          {/* ---------------------------------------------
              Default Recipe Sections
          --------------------------------------------- */}

          <section
            className="
              mt-6
              flex
              flex-col
              gap-6
              px-3

              sm:px-5
              md:px-6

              lg:flex-row
              lg:flex-wrap
              lg:justify-center
            "
          >
            <Defaultrecipes
              defaultRecipes={defaultRecipes.chicken}
              saveRecipe={saveRecipe}
              dishName="Chicken"
            />

            <Defaultrecipes
              defaultRecipes={defaultRecipes.beef}
              saveRecipe={saveRecipe}
              dishName="Beef"
            />

            <Defaultrecipes
              defaultRecipes={defaultRecipes.rice}
              saveRecipe={saveRecipe}
              dishName="Rice"
            />
          </section>

          {/* ---------------------------------------------
              Recipe Modal
          --------------------------------------------- */}

          {recipe !== null && (
            <div
              className="
                fixed
                inset-0
                z-50

                flex
                items-center
                justify-center

                bg-black/40
                p-4
              "
            >
              <div
                className="
                  relative
                  max-h-[85vh]
                  w-full
                  max-w-2xl
                  overflow-y-auto

                  rounded-2xl
                  bg-white
                  p-5
                  shadow-2xl

                  sm:p-6
                "
              >
                {/* Close */}

                <button
                  onClick={() => setRecipe(null)}
                  className="
                    absolute
                    right-4
                    top-4
                    rounded-full
                    p-2
                    text-gray-600
                    transition
                    hover:bg-gray-100
                    hover:text-black
                  "
                >
                  <X className="size-5" />
                </button>

                <div className="pr-8">
                  <h2 className="mb-4 text-xl font-bold text-green-950 sm:text-2xl">
                    Recipe Instructions
                  </h2>

                  <p className="whitespace-pre-line text-sm leading-6 text-gray-700 sm:text-base">
                    {recipe}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* ---------------------------------------------
              Random Recipe
          --------------------------------------------- */}

          {random !== null ? (
            <section className="px-3 py-6 sm:px-5 md:px-6">
              <RandomRecipe random={random} saveRecipe={saveRecipe} />
            </section>
          ) : (
            searchQuery.trim() !== "" && (
              <section className="px-3 py-6 sm:px-5 md:px-6">
                {/* Search heading */}

                <div className="mb-6">
                  <div className="flex items-center gap-2">
                    <ChefHat className="size-6 text-green-950 sm:size-7" />

                    <h1
                      className="
                        text-2xl
                        font-bold
                        text-green-950

                        sm:text-3xl
                      "
                    >
                      Search Results
                    </h1>
                  </div>

                  <p className="mt-1 text-sm font-medium text-gray-600 sm:text-base">
                    Found {recipes.length}{" "}
                    {recipes.length === 1 ? "recipe" : "recipes"}
                  </p>

                  {error && (
                    <div
                      className="
                        mt-4
                        rounded-lg
                        border
                        border-red-200
                        bg-red-50
                        px-4
                        py-3
                        text-sm
                        font-semibold
                        text-red-600
                      "
                    >
                      {error}
                    </div>
                  )}
                </div>

                {/* -----------------------------------------
                    Recipe Cards
                ----------------------------------------- */}

                {recipes.length > 0 && (
                  <div
                    className="
                      grid
                      grid-cols-1
                      gap-5

                      sm:grid-cols-2

                      md:grid-cols-3

                      lg:grid-cols-3

                      xl:grid-cols-4
                    "
                  >
                    {recipes.map((recipe) => (
                      <article
                        key={recipe.idMeal}
                        className="
                          group
                          overflow-hidden
                          rounded-2xl
                          border
                          border-gray-200
                          bg-white
                          shadow-sm

                          transition-all
                          duration-300

                          hover:-translate-y-1
                          hover:shadow-xl
                        "
                      >
                        {/* Image */}

                        <div className="relative overflow-hidden">
                          <img
                            src={recipe.strMealThumb}
                            alt={recipe.strMeal}
                            className="
                              h-52
                              w-full
                              object-cover

                              transition
                              duration-500

                              group-hover:scale-105

                              sm:h-48

                              lg:h-52
                            "
                          />

                          {/* Image overlay */}

                          <div
                            className="
                              absolute
                              inset-0
                              bg-gradient-to-t
                              from-black/30
                              via-transparent
                              to-transparent
                            "
                          />

                          {/* Heart */}

                          <button
                            onClick={() => saveRecipe(recipe)}
                            className="
                              absolute
                              right-3
                              top-3

                              flex
                              size-9
                              items-center
                              justify-center

                              rounded-full
                              bg-white/90

                              shadow-md
                              backdrop-blur-sm

                              transition

                              hover:scale-110
                            "
                            title="Save recipe"
                          >
                            <Heart className="size-4 text-green-950" />
                          </button>
                        </div>

                        {/* Card Content */}

                        <div className="p-4">
                          {/* Recipe Name */}

                          <h2
                            className="
                              line-clamp-2
                              min-h-[48px]
                              text-base
                              font-bold
                              leading-6
                              text-gray-900

                              sm:text-lg
                            "
                            title={recipe.strMeal}
                          >
                            {recipe.strMeal}
                          </h2>

                          {/* Country */}

                          <div className="mt-2 flex items-center gap-2">
                            <span className="text-xs font-semibold uppercase tracking-wide text-gray-400">
                              Origin
                            </span>

                            <span className="truncate text-sm font-medium text-gray-600">
                              {recipe.strCountry || "Unknown"}
                            </span>
                          </div>

                          {/* Buttons */}

                          <div className="mt-4 grid grid-cols-2 gap-2">
                            <button
                              onClick={() => saveRecipe(recipe)}
                              className="
                                rounded-xl
                                bg-green-950
                                px-2
                                py-2

                                text-xs
                                font-bold
                                text-white

                                transition

                                hover:bg-green-900
                                active:scale-95

                                sm:text-sm
                              "
                            >
                              Save Recipe
                            </button>

                            <button
                              onClick={() =>
                                navigate(`/recipe/${recipe.idMeal}`)
                              }
                              className="
                                rounded-xl
                                bg-blue-900
                                px-2
                                py-2

                                text-xs
                                font-bold
                                text-white

                                transition

                                hover:bg-blue-800
                                active:scale-95

                                sm:text-sm
                              "
                            >
                              Get Recipe
                            </button>
                          </div>
                        </div>
                      </article>
                    ))}
                  </div>
                )}
              </section>
            )
          )}
        </main>
      </div>
    </div>
  );
};
