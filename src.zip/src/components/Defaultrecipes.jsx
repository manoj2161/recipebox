import { ChevronLeft, ChevronRight } from "lucide-react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

export const Defaultrecipes = ({ defaultRecipes, saveRecipe, dishName }) => {
  const [defaultRecipieIndex, setDefaultRecipieIndex] = useState(0);
  const navigate = useNavigate();
  if (!defaultRecipes || defaultRecipes.length === 0) {
    return null;
  }

  return (
    <div className="flex flex-col">
      <div className="relative w-[750px] h-88">
        <div className="mb-4">
          <h1 className="text-3xl font-bold text-green-950">
            {dishName} Recipes
          </h1>

          <p className="font-semibold">
            Found {defaultRecipes.length} recipes of "{dishName.toLowerCase()}"
          </p>
        </div>

        {/* LEFT BUTTON */}
        <button
          onClick={() => setDefaultRecipieIndex((prev) => prev - 1)}
          disabled={defaultRecipieIndex === 0}
          className="w-10 h-10 rounded-full font-semibold bg-white text-black shadow absolute left-0 top-34 z-10 disabled:opacity-30"
        >
          <ChevronLeft className="ml-1.5" />
        </button>

        {/* RIGHT BUTTON */}
        <button
          onClick={() => setDefaultRecipieIndex((prev) => prev + 1)}
          disabled={defaultRecipieIndex + 4 >= defaultRecipes.length}
          className="w-10 h-10 rounded-full font-semibold bg-white text-black shadow absolute right-0 top-34 z-10 disabled:opacity-30"
        >
          <ChevronRight className="ml-2" />
        </button>

        {/* CAROUSEL VIEWPORT */}
        <div className="overflow-hidden w-[720px]">
          {/* CAROUSEL TRACK */}
          <div
            className="flex gap-3 transition-transform duration-500 ease-in-out"
            style={{
              transform: `translateX(-${defaultRecipieIndex * 25}%)`,
            }}
          >
            {defaultRecipes.map((recipe) => (
              <div
                key={recipe.idMeal}
                className="shadow rounded-lg w-44 shrink-0 overflow-hidden bg-white"
              >
                {/* IMAGE */}
                <div className="w-full">
                  <img
                    src={recipe.strMealThumb}
                    alt={recipe.strMeal}
                    className="rounded-lg w-full h-40 object-cover"
                  />
                </div>

                {/* DETAILS */}
                <div className="p-1 text-sm font-semibold">
                  <p className="truncate">Name : {recipe.strMeal}</p>

                  <p>Country : {recipe.strCountry || "Unknown"}</p>
                </div>

                {/* BUTTONS */}
                <div className="flex gap-1 px-1 py-2">
                  <button
                    onClick={() => saveRecipe(recipe)}
                    className="rounded-xl bg-green-950 text-sm font-semibold text-white p-1"
                  >
                    Save
                  </button>

                  <button
                    className="rounded-xl bg-blue-900 text-sm font-semibold text-white p-1"
                    onClick={() => navigate(`/recipe/${recipe.idMeal}`)}
                  >
                    Get Recipe
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
