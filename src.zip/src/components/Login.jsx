import { Mail, Lock, Eye, EyeClosed } from "lucide-react";
import logo from "../assets/logo.png";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
export const Login = ({ setIsLoggedIn }) => {
  const [pass, setpass] = useState(false);
  const [loader, setLoader] = useState(false);
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  function handleChange(e) {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
    setErrors((prev) => ({
      ...prev,
      [name]: "",
    }));
  }
  function handleLogin(e) {
    e.preventDefault();
    const newErrors = {};
    const usersData = JSON.parse(localStorage.getItem("recipeBoxUsers")) || [];
    const existingUser = usersData.find(
      (user) => user.email === formData.email,
    );
    if (!formData.email.trim()) {
      newErrors.email = "Email is required";
    } else if (!existingUser) {
      newErrors.email = "User does not exits";
    }
    if (!formData.password.trim()) {
      newErrors.password = "Password is required";
    } else if (
      existingUser &&
      formData.password.trim() !== existingUser.password
    ) {
      newErrors.password = "Incorrect Password";
    }
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }
    console.log(existingUser);
    localStorage.setItem(
      "recipeBoxCurrentUser",
      JSON.stringify(existingUser.id),
    );
    savePendingRecipe();
    setLoader(true);
    setTimeout(() => {
      setLoader(false);
      setIsLoggedIn(true);
      navigate("/search");
    }, 1000);
  }

  function savePendingRecipe() {
    const pendingRecipe = sessionStorage.getItem("pendingRecipe");

    if (!pendingRecipe) {
      return;
    }

    const recipe = JSON.parse(pendingRecipe);

    const currentUser = JSON.parse(
      localStorage.getItem("recipeBoxCurrentUser"),
    );

    const usersData = JSON.parse(localStorage.getItem("recipeBoxUsers")) || [];

    const loggedUser = usersData.find((user) => user.id === currentUser);

    if (!loggedUser) {
      return;
    }

    loggedUser.recipies = loggedUser.recipies || [];

    const existingRecipe = loggedUser.recipies.find(
      (item) => item.idMeal === recipe.idMeal,
    );

    if (!existingRecipe) {
      loggedUser.recipies.push(recipe);
    }

    localStorage.setItem("recipeBoxUsers", JSON.stringify(usersData));

    sessionStorage.removeItem("pendingRecipe");

    console.log("Pending recipe saved:", recipe);
  }
  return (
    <>
      <div className="lg:flex lg:items-center md:flex md:items-center md:justify-center h-screen w-full font-['Kaushan_Script']">
        <div className=" lg:h-screen md:h-screen lg:w-[40%] md:w-[40%] w-full h-[40%] bg-green-900 lg:rounded-none md:rounded-none rounded-b-full">
          <div className="lg:flex lg:flex-col lg:justify-center lg:mt-28 lg:gap-28 lg:items-center md:flex md:flex-col md:justify-center md:mt-28 md:gap-28 md:items-center flex flex-col justify-center items-center text-white font-bold gap-4">
            <div className="lg:flex lg:flex-col lg:justify-center lg:items-center lg:gap-4 md:flex md:flex-col md:justify-center md:items-center md:gap-4 flex flex-col justify-center items-center gap-8 p-4">
              <img src={logo} className="lg:size-38 md:size-38 size-46" />
              <p className="lg:text-3xl text-center md:text-3xl text-3xl">
                <span>Welcome Back ! </span>
                <br />
                <span>
                  Good food is always a<br />
                  Good Idea.
                </span>
              </p>
            </div>
          </div>
        </div>
        <div className="flex flex-col justify-center items-center md:w-[60%] lg:w-[60%] w-full">
          <h1 className="text-center text-[48px] text-green-950 font-bold lg:mt-16 md:mt-16 mt-4">
            Login
          </h1>
          <form onSubmit={handleLogin} className="flex flex-col ">
            <div className="h-22 relative flex flex-col">
              <Mail className="absolute top-9 left-1 text-green-950" />
              <label htmlFor="email" className="text-lg font-semibold">
                Email
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                className="border rounded h-10 lg:w-118 w-88 border-green-950 pl-8"
                onChange={handleChange}
                placeholder="Email Address"
              />
              <span className="text-red-500 absolute left-11">*</span>
              {errors.email && (
                <p className="text-red-500 text-sm">{errors.email}</p>
              )}
            </div>
            <div className=" h-22 relative flex flex-col">
              <Lock className="absolute top-9 left-1 text-green-950" />
              <label htmlFor="password" className="text-lg font-semibold">
                Password
              </label>
              <input
                type={pass ? "text" : "password"}
                value={formData.password}
                name="password"
                className=" rounded h-10 w-88 lg:w-118 border border-green-950 pl-8"
                onChange={handleChange}
                placeholder="Password"
              />
              {pass ? (
                <EyeClosed
                  className="absolute right-2 top-9"
                  onClick={() => setpass((prev) => !prev)}
                />
              ) : (
                <Eye
                  className="absolute right-2 top-9"
                  onClick={() => setpass((prev) => !prev)}
                />
              )}

              <span className="text-red-500 absolute left-16">*</span>
              {errors.password && (
                <p className="text-red-500 text-sm">{errors.password}</p>
              )}
            </div>
            <div className="relative h-6">
              <button
                onClick={() => navigate("/forgot")}
                className="absolute right-2 font-semibold"
              >
                Forgot Password ?
              </button>
            </div>
            <div className=" h-22 relative flex flex-col">
              {!loader ? (
                <button
                  type="submit"
                  className="bg-green-950 rounded-lg my-4 py-2 text-white font-semibold text-lg"
                >
                  Login
                </button>
              ) : (
                <div className="border border-green-900 absolute size-6 rounded-full border-4 animate-spin border-t-gray-200 top-6 left-[50%]"></div>
              )}
            </div>
            <p className="text-center">
              Don't have an account?
              <button
                onClick={() => navigate("/signup")}
                className="text-green-950 font-bold ml-1"
              >
                Sign Up
              </button>
            </p>
          </form>
        </div>
      </div>
    </>
  );
};
