import { useEffect, useState } from "react";
import { AsideNavbar } from "./AsideNavbar";
import { useNavigate } from "react-router-dom";
export const SavedRecipes = ({ isLoggedIn, setIsLoggedIn }) => {
  const [myRecipies, setMyRecipies] = useState([]);

  const navigate = useNavigate();
  useEffect(() => {
    const users = JSON.parse(localStorage.getItem("recipeBoxUsers")) || [];
    const currentUser = JSON.parse(
      localStorage.getItem("recipeBoxCurrentUser"),
    );
    const loggedUser = users.find((user) => user.id === currentUser);
    if (!loggedUser) {
      return;
    }
    const recipies = loggedUser.recipies;
    setMyRecipies(recipies);
  }, []);
  return (
    <>
      <div className="flex">
        <AsideNavbar isLoggedIn={isLoggedIn} setIsLoggedIn={setIsLoggedIn} />
        <main>
          <section>
            <h1 className="text-center text-4xl font-bold text-green-950 p-4">
              My Recipes
            </h1>
            <div className="grid grid-cols-4 gap-8 mx-8 relative">
              {myRecipies.map((recipe) => (
                <div
                  key={recipe.idMeal}
                  className="shadow rounded-lg w-44 shrink-0 overflow-hidden bg-white"
                >
                  <div className="w-full">
                    <img
                      src={recipe.strMealThumb}
                      alt={recipe.strMeal}
                      className="rounded-lg w-full h-40 object-cover"
                    />
                  </div>
                  <div className="p-1 text-sm font-semibold">
                    <p className="truncate">Name : {recipe.strMeal}</p>

                    <p>Country : {recipe.strCountry || "Unknown"}</p>
                  </div>

                  <div className="flex gap-1 px-1 py-2">
                    <button
                      className="rounded-xl bg-blue-900 text-sm font-semibold text-white p-1"
                      onClick={() => navigate(`/recipe/${recipe.idMeal}`)}
                    >
                      Get Recipe
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </main>
      </div>
    </>
  );
};
