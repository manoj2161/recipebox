
import {
  Mail,
  Lock,
  User,
  Eye,
  EyeClosed,
} from "lucide-react";

import logo from "../assets/logo.png";
import { useNavigate } from "react-router-dom";
import { useState } from "react";

export const Signup = () => {
  const [pass, setpass] = useState(false);
  const [cpass, setcpass] = useState(false);
  const [loader, setLoader] = useState(false);

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    cpassword: "",
  });

  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  function handleChange(e) {
    const { name, value } = e.target;

    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));

    setErrors((prev) => ({
      ...prev,
      [name]: "",
    }));
  }

  function handleSignup(e) {
    e.preventDefault();

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const newErrors = {};

    const usersData =
      JSON.parse(localStorage.getItem("recipeBoxUsers")) || [];

    const existingUser = usersData.find(
      (user) => user.email === formData.email.trim()
    );

    if (!formData.name.trim()) {
      newErrors.name = "Name is required";
    }

    if (!formData.email.trim()) {
      newErrors.email = "Email is required";
    } else if (!emailRegex.test(formData.email.trim())) {
      newErrors.email = "Please enter a valid email";
    } else if (existingUser) {
      newErrors.email = "User already exists";
    }

    if (!formData.password.trim()) {
      newErrors.password = "Password is required";
    } else if (formData.password.length < 6) {
      newErrors.password = "Password should be at least 6 characters";
    }

    if (!formData.cpassword.trim()) {
      newErrors.cpassword = "Confirm Password is required";
    } else if (formData.cpassword !== formData.password) {
      newErrors.cpassword = "Password does not match";
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    const newUser = {
      id: crypto.randomUUID(),
      name: formData.name.trim(),
      email: formData.email.trim(),
      password: formData.password.trim(),
      cpassword: formData.cpassword.trim(),
      recipies: [],
    };

    usersData.push(newUser);

    localStorage.setItem(
      "recipeBoxUsers",
      JSON.stringify(usersData)
    );

    setLoader(true);

    setTimeout(() => {
      setLoader(false);
      navigate("/login");
    }, 1000);
  }

  return (
    <div className="lg:flex lg:items-center md:flex md:items-center md:justify-center h-screen w-full font-['Kaushan_Script']">

      {/* LEFT / TOP SECTION */}
      <div
        className="
          lg:h-screen md:h-screen
          lg:w-[40%] md:w-[40%]
          w-full h-[40%]
          bg-green-900
          lg:rounded-none md:rounded-none
          rounded-b-full
        "
      >
        <div
          className="
            lg:flex lg:flex-col lg:justify-center
            lg:mt-28 lg:gap-28 lg:items-center

            md:flex md:flex-col md:justify-center
            md:mt-28 md:gap-28 md:items-center

            flex flex-col justify-center items-center
            text-white font-bold gap-4
          "
        >
          <div
            className="
              lg:flex lg:flex-col lg:justify-center
              lg:items-center lg:gap-4

              md:flex md:flex-col md:justify-center
              md:items-center md:gap-4

              flex flex-col justify-center
              items-center gap-8 p-4
            "
          >
            <img
              src={logo}
              alt="RecipeBox Logo"
              className="lg:size-38 md:size-38 size-46"
            />

            <p className="lg:text-3xl text-center md:text-3xl text-3xl">
              <span>Create Your Account</span>
              <br />
              <span>
                Start your recipe<br />
                journey.
              </span>
            </p>
          </div>
        </div>
      </div>

      {/* SIGNUP FORM */}
      <div
        className="
          flex flex-col justify-center items-center
          md:w-[60%] lg:w-[60%]
          w-full
        "
      >
        <h1
          className="
            text-center text-[48px]
            text-green-950 font-bold
            lg:mt-16 md:mt-16 mt-4
          "
        >
          Sign Up
        </h1>

        <form
          onSubmit={handleSignup}
          className="flex flex-col"
        >

          {/* NAME */}
          <div className="h-22 relative flex flex-col">
            <User
              className="
                absolute top-9 left-1
                text-green-950
              "
            />

            <label
              htmlFor="name"
              className="text-lg font-semibold"
            >
              Full Name
            </label>

            <span className="text-red-500 absolute left-18">
              *
            </span>

            <input
              id="name"
              type="text"
              name="name"
              value={formData.name}
              className="
                border rounded h-10
                w-88 lg:w-118
                border-green-950
                pl-8
              "
              placeholder="Full Name"
              onChange={handleChange}
            />

            {errors.name && (
              <p className="text-red-500 text-sm">
                {errors.name}
              </p>
            )}
          </div>

          {/* EMAIL */}
          <div className="h-22 relative flex flex-col">
            <Mail
              className="
                absolute top-9 left-1
                text-green-950
              "
            />

            <label
              htmlFor="email"
              className="text-lg font-semibold"
            >
              Email
            </label>

            <span className="text-red-500 absolute left-11">
              *
            </span>

            <input
              id="email"
              type="email"
              name="email"
              value={formData.email}
              className="
                border rounded h-10
                w-88 lg:w-118
                border-green-950
                pl-8
              "
              onChange={handleChange}
              placeholder="Email Address"
            />

            {errors.email && (
              <p className="text-red-500 text-sm">
                {errors.email}
              </p>
            )}
          </div>

          {/* PASSWORD */}
          <div className="h-22 relative flex flex-col">
            <Lock
              className="
                absolute top-9 left-1
                text-green-950
              "
            />

            <label
              htmlFor="password"
              className="text-lg font-semibold"
            >
              Password
            </label>

            <span className="text-red-500 absolute left-16">
              *
            </span>

            <input
              id="password"
              type={pass ? "text" : "password"}
              name="password"
              value={formData.password}
              className="
                rounded h-10
                w-88 lg:w-118
                border border-green-950
                pl-8
              "
              onChange={handleChange}
              placeholder="Password"
            />

            {pass ? (
              <EyeClosed
                className="absolute right-2 top-9 cursor-pointer"
                onClick={() => setpass((prev) => !prev)}
              />
            ) : (
              <Eye
                className="absolute right-2 top-9 cursor-pointer"
                onClick={() => setpass((prev) => !prev)}
              />
            )}

            {errors.password && (
              <p className="text-red-500 text-sm">
                {errors.password}
              </p>
            )}
          </div>

          {/* CONFIRM PASSWORD */}
          <div className="h-22 relative flex flex-col">
            <Lock
              className="
                absolute top-9 left-1
                text-green-950
              "
            />

            <label
              htmlFor="cpassword"
              className="text-lg font-semibold"
            >
              Confirm Password
            </label>

            <span className="text-red-500 absolute left-32">
              *
            </span>

            <input
              id="cpassword"
              type={cpass ? "text" : "password"}
              name="cpassword"
              value={formData.cpassword}
              className="
                rounded h-10
                w-88 lg:w-118
                border border-green-950
                pl-8
              "
              onChange={handleChange}
              placeholder="Confirm Password"
            />

            {cpass ? (
              <EyeClosed
                className="absolute right-2 top-9 cursor-pointer"
                onClick={() => setcpass((prev) => !prev)}
              />
            ) : (
              <Eye
                className="absolute right-2 top-9 cursor-pointer"
                onClick={() => setcpass((prev) => !prev)}
              />
            )}

            {errors.cpassword && (
              <p className="text-red-500 text-sm">
                {errors.cpassword}
              </p>
            )}
          </div>

          {/* SIGNUP BUTTON */}
          <div className="h-22 relative flex flex-col">
            {!loader ? (
              <button
                type="submit"
                className="
                  bg-green-950
                  rounded-lg
                  my-4 py-2
                  text-white
                  font-semibold
                  text-lg
                  w-88 lg:w-118
                "
              >
                Create Account
              </button>
            ) : (
              <div
                className="
                  border border-green-900
                  absolute size-6
                  rounded-full border-4
                  animate-spin
                  border-t-gray-200
                  top-6 left-[50%]
                "
              ></div>
            )}
          </div>

          {/* LOGIN LINK */}
          <p className="text-center">
            Already have an account?

            <button
              type="button"
              onClick={() => navigate("/login")}
              className="
                text-green-950
                font-bold
                ml-1
              "
            >
              Login
            </button>
          </p>

        </form>
      </div>
    </div>
  );
};
