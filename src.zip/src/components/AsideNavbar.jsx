import { useNavigate } from "react-router-dom";
import logo from "../assets/logo.png";
import { Home, LogOutIcon, NotepadText, ShoppingBasket } from "lucide-react";

export const AsideNavbar = ({ isLoggedIn, setIsLoggedIn }) => {
  const navigate = useNavigate();

  function handleLogout() {
    localStorage.removeItem("recipeBoxCurrentUser");
    setIsLoggedIn(false);
    navigate("/");
  }

  return (
    <>
      {/* =========================================
          DESKTOP SIDEBAR
      ========================================= */}

      <aside
        className="
          hidden
          lg:flex
          fixed
          left-0
          top-0
          z-40
          h-screen
          w-64
          flex-col
          justify-between
          rounded-r-2xl
          bg-white
          shadow-lg
        "
      >
        {/* Top section */}

        <div>
          {/* Logo */}

          <div className="flex justify-center px-6 py-6">
            <img
              src={logo}
              alt="RecipeBox logo"
              className="h-24 w-24 object-contain"
            />
          </div>

          {/* Navigation */}

          <div className="mt-6 px-5">
            <nav className="flex flex-col gap-2">
              {/* Home */}

              <button
                onClick={() => navigate("/search")}
                className="
                  flex
                  h-10
                  w-full
                  items-center
                  gap-3
                  rounded-xl
                  px-3
                  font-bold
                  text-green-950
                  transition
                  hover:bg-green-100
                  hover:text-black
                "
              >
                <Home className="size-5" />

                <p>Home</p>
              </button>

              {/* My Recipes */}

              {isLoggedIn && (
                <button
                  onClick={() => navigate("/myrecipes")}
                  className="
                    flex
                    h-10
                    w-full
                    items-center
                    gap-3
                    rounded-xl
                    px-3
                    font-bold
                    text-green-950
                    transition
                    hover:bg-green-100
                    hover:text-black
                  "
                >
                  <NotepadText className="size-5" />

                  <p>My Recipes</p>
                </button>
              )}

              {/* Shopping List */}

              {isLoggedIn && (
                <button
                  className="
                    flex
                    h-10
                    w-full
                    items-center
                    gap-3
                    rounded-xl
                    px-3
                    font-bold
                    text-green-950
                    transition
                    hover:bg-green-100
                    hover:text-black
                  "
                >
                  <ShoppingBasket className="size-5" />

                  <p>Shopping List</p>
                </button>
              )}
            </nav>
          </div>
        </div>

        {/* Logout */}

        {isLoggedIn && (
          <div className="border-t border-gray-100 p-5">
            <button
              onClick={handleLogout}
              className="
                flex
                h-10
                w-full
                items-center
                gap-3
                rounded-xl
                px-3
                font-bold
                text-green-950
                transition
                hover:bg-red-50
                hover:text-red-600
              "
            >
              <LogOutIcon className="size-5" />

              <p>Logout</p>
            </button>
          </div>
        )}
      </aside>

      {/* =========================================
          MOBILE / TABLET BOTTOM NAVIGATION
      ========================================= */}

      <nav
        className="
          fixed
          bottom-0
          left-0
          right-0
          z-50

          flex
          h-16
          items-center
          justify-around

          border-t
          border-gray-200
          bg-white

          shadow-[0_-4px_15px_rgba(0,0,0,0.08)]

          lg:hidden
        "
      >
        {/* Home */}

        <button
          onClick={() => navigate("/search")}
          className="
            flex
            min-w-[60px]
            flex-col
            items-center
            justify-center
            gap-1
            text-green-950
          "
        >
          <Home className="size-5" />

          <span className="text-[10px] font-semibold">Home</span>
        </button>

        {/* My Recipes */}

        {isLoggedIn && (
          <button
            onClick={() => navigate("/myrecipes")}
            className="
              flex
              min-w-[60px]
              flex-col
              items-center
              justify-center
              gap-1
              text-green-950
            "
          >
            <NotepadText className="size-5" />

            <span className="text-[10px] font-semibold">My Recipes</span>
          </button>
        )}

        {/* Shopping List */}

        {isLoggedIn && (
          <button
            className="
              flex
              min-w-[60px]
              flex-col
              items-center
              justify-center
              gap-1
              text-green-950
            "
          >
            <ShoppingBasket className="size-5" />

            <span className="text-[10px] font-semibold">Shopping</span>
          </button>
        )}

        {/* Logout */}

        {isLoggedIn && (
          <button
            onClick={handleLogout}
            className="
              flex
              min-w-[60px]
              flex-col
              items-center
              justify-center
              gap-1
              text-red-500
            "
          >
            <LogOutIcon className="size-5" />

            <span className="text-[10px] font-semibold">Logout</span>
          </button>
        )}
      </nav>
    </>
  );
};
