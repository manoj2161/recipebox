import axios from "axios";
import { useParams } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Heart, Share2 } from "lucide-react";
import { useEffect, useState } from "react";
export const FullRecipe = () => {
  const [fullRecipe, setRecipe] = useState(null);
  const { id } = useParams();
  const navigate = useNavigate();
  useEffect(() => {
    async function fetchFullRecipe() {
      try {
        const response = await axios.get(
          `https://www.themealdb.com/api/json/v1/1/lookup.php?i=${id}`,
        );

        const recipe = response.data.meals?.[0];

        if (!recipe) {
          console.log("recipe not found");
          return;
        }
        console.log(recipe);

        setRecipe(recipe);
      } catch (error) {
        console.log(error);
      }
    }
    fetchFullRecipe();
  }, []);
  if (!fullRecipe) {
    return (
      <div className="MT-88 border border-green-900 absolute size-6 rounded-full border-4 animate-spin border-t-gray-200 top-6 left-[50%]"></div>
    );
  }

  const ingredients = [];
  for (let i = 1; i <= 20; i++) {
    const ingredient = fullRecipe[`strIngredient${i}`];
    const measure = fullRecipe[`strMeasure${i}`];
    if (ingredient && ingredient.trim() !== "") {
      ingredients.push({ ingredient, measure });
    }
  }
  const steps = fullRecipe.strInstructions
    .split(/\r?\n/)
    .filter((step) => step.trim() !== "");
  return (
    <>
      <section className="w-full h-screen rounded-lg">
        <header className="flex justify-between items-center h-8 shadow">
          <div className=" ml-2">
            <button
              onClick={() => navigate(-1)}
              className="flex gap-2 items-center"
            >
              <ArrowLeft className="size-5" />
              Back
            </button>
          </div>
          <div className="flex gap-6 px-4">
            <button>
              <Heart />
            </button>
            <button>
              <Share2 />
            </button>
          </div>
        </header>
        <main>
          <div className="m-4">
            <div className="w-full h-68 flex gap-32 shadow-lg p-4">
              <img
                src={fullRecipe.strMealThumb}
                className="h-full w-88 rounded-xl shadow-xl"
                alt=""
              />
              <div className=" w-88 flex flex-col">
                <h1 className="text-4xl font-bold ml-3">
                  {fullRecipe.strMeal}
                </h1>
                <span className="bg-orange-700 w-28 text-center rounded-full text-white text-sm border m-2 py-1">
                  {fullRecipe.strCategory}
                </span>
                <button className="flex items-center justify-center gap-3 bg-green-950 h-10 rounded-full text-white mx-2 shadow-lg">
                  <Heart /> Save to My Recipes
                </button>
              </div>
            </div>
            <div className="w-full h-full flex">
              <div className=" p-4 w-[50%]">
                <h2 className="text-2xl font-bold mb-4">Ingredients</h2>
                <div className="space-y-2">
                  {ingredients.map((item, index) => (
                    <div key={index}>
                      <span className="w-48 font-semibold mr-2">
                        {item.measure}
                      </span>
                      <span>({item.ingredient})</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="w-[50%]">
                <section className="mt-3">
                  <h2 className="text-2xl font-bold mb-4">Instructions</h2>
                  <div className="space-y-5">
                    {steps.map((step, index) => (
                      <div key={index} className="flex gap-2">
                        <div className="flex-shrink-0 w-8 h-8 rounded-full bg-green-950 text-white flex items-center justify-center font-bold">
                          {index + 1}
                        </div>

                        <p className="leading-6">{step}</p>
                      </div>
                    ))}
                  </div>
                </section>
              </div>
            </div>
          </div>
        </main>
      </section>
    </>
  );
};
