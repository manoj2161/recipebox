import { useNavigate } from "react-router-dom";
import { Search, Bookmark } from "lucide-react";
export const HeaderDashboard = ({
  newSearch,
  setNewSearch,
  setSearchQuery,
  name,
  isLoggedIn,
}) => {
  const navigate = useNavigate();
  return (
    <>
      <header className="flex justify-between items-center">
        <div className="relative h-21 w-88 lg:w-198 md:w-148 ml-2">
          <Search className="absolute left-2 bottom-5.5 md:size-7 text-green-950 z-20 size-5" />

          <input
            type="text"
            name="search"
            value={newSearch}
            onChange={(e) => setNewSearch(e.target.value)}
            placeholder="Search for recipes... (eg. chicken, pasta etc.)"
            className="border border-green-950 w-88 lg:w-148 placeholder:text-xs md:placeholder:text-lg rounded-full h-11.5 absolute top-4 md:w-128 h-15 bg-white pl-10"
          />

          <button
            onClick={() => setSearchQuery(newSearch)}
            className="absolute bottom-4 md:px-6 md:py-5 md:left-113 lg:left-134 left-76 bg-green-950 rounded-2xl border px-5 py-4"
          >
            <Search className="absolute bottom-2 md:size-6 right-3 text-white z-30 size-5" />
          </button>
        </div>

        <div className="flex gap-12 mr-4 items-center">
          {isLoggedIn && (
            <button
              className="p-2 shadow-xl rounded-full border border-gray-100"
              onClick={() => navigate("/myrecipes")}
            >
              <Bookmark />
            </button>
          )}
          {isLoggedIn && (
            <button className="text-center w-10 h-10 text-sm shadow-xl rounded-full border border-gray-100 bg-green-950 text-white">
              {name}
            </button>
          )}
          {!isLoggedIn && (
            <button
              onClick={() => navigate("/login")}
              className="rounded-3xl py-1 md:py-2 md:px-2 md:text-lg font-bold shadow-xl border bg-green-950 text-white border-green-950 px-2"
            >
              Login
            </button>
          )}
        </div>
      </header>
    </>
  );
};
