import { useNavigate } from "react-router-dom";
import { Search } from "lucide-react";
import { useState } from "react";
import logo from "../assets/logo.png";

export const Header = () => {
  const [recipeSearch, setRecipeSearch] = useState("");
  const navigate = useNavigate();

  function handleSearch() {
    if (!recipeSearch.trim()) {
      return;
    }

    navigate("/search", {
      state: {
        query: recipeSearch.trim(),
      },
    });
  }

  return (
    <div className="min-h-[100svh] w-full flex flex-col">
      {/* Header */}
      <header className="w-full px-4 py-4 sm:px-6 md:px-8 lg:px-12">
        <div className="flex items-center justify-between gap-4">
          {/* Logo */}
          <div className="flex items-center">
            <img
              src={logo}
              alt="RecipeBox logo"
              className="size-14 sm:size-16 md:size-20 lg:size-24"
            />

            <span
              className="
                font-['Kaushan_Script']
                text-xl
                sm:text-2xl
                md:text-3xl
                lg:text-4xl
                xl:text-5xl
                font-bold
                text-green-950
              "
            >
              RecipeBox
            </span>
          </div>

          {/* Navigation */}
          <nav className="flex items-center gap-2 sm:gap-3 md:gap-4">
            <button
              onClick={() => navigate("/login")}
              className="
                rounded-full
                border border-green-950
                px-3 py-1.5
                sm:px-4 sm:py-2
                md:px-5
                text-sm
                sm:text-base
                md:text-lg
                font-bold
                shadow-lg
                whitespace-nowrap
              "
            >
              Login
            </button>

            <button
              onClick={() => navigate("/signup")}
              className="
                rounded-full
                bg-green-950
                px-3 py-1.5
                sm:px-4 sm:py-2
                md:px-5
                text-sm
                sm:text-base
                md:text-lg
                font-semibold
                text-white
                shadow-lg
                whitespace-nowrap
              "
            >
              Sign Up
            </button>
          </nav>
        </div>
      </header>

      {/* Search Section */}
      <div className="flex flex-1 items-center justify-center px-4">
        <div className="w-full max-w-3xl">
          <div className="flex w-full items-center gap-2">
            {/* Input */}
            <div className="relative flex-1">
              <Search
                className="
                  absolute
                  left-3
                  top-1/2
                  size-5
                  -translate-y-1/2
                  text-green-950
                  sm:size-6
                "
              />

              <input
                type="text"
                name="search"
                value={recipeSearch}
                onChange={(e) => setRecipeSearch(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    handleSearch();
                  }
                }}
                placeholder="Search for recipes..."
                className="
                  h-11
                  w-full
                  rounded-full
                  border
                  border-green-950
                  bg-white
                  pl-10
                  pr-4
                  text-sm
                  outline-none

                  focus:ring-2
                  focus:ring-green-950

                  sm:h-12
                  sm:pl-11
                  sm:text-base

                  md:h-14
                  md:text-lg
                "
              />
            </div>

            {/* Search Button */}
            <button
              onClick={handleSearch}
              className="
                flex
                size-11
                shrink-0
                items-center
                justify-center
                rounded-full
                bg-green-950
                text-white
                shadow-lg

                sm:size-12
                md:size-14
              "
            >
              <Search className="size-5 sm:size-6 md:size-7" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
