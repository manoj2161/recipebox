import { useNavigate } from "react-router-dom";

export const RandomRecipe = ({ random, saveRecipe }) => {
  const navigate = useNavigate();
  return (
    <>
      <div className="relative w-full p-4 shadow rounded-xl">
        <h1 className="text-3xl font-bold text-green-950 mb-4 text-center">
          Random Recipe for you
        </h1>
        <section className="flex gap-8">
          <div className="shadow rounded-lg">
            <img
              src={random.strMealThumb}
              alt={random.strMeal}
              className="rounded-lg h-48 object-cover"
            />
          </div>
          <div className="flex flex-col gap-16">
            <div className="p-1 text-3xl font-bold">
              <p>Name : {random.strMeal}</p>

              <p>Country : {random.strCountry || "Unknown"}</p>
            </div>
            <div className="flex gap-1 px-1 py-2">
              <button
                onClick={() => saveRecipe(random)}
                className="rounded-xl bg-green-950 text-sm font-semibold text-white p-1"
              >
                Save Recipe
              </button>

              <button
                className="rounded-xl bg-blue-900 text-sm font-semibold text-white p-1"
                onClick={() => navigate(`/recipe/${random.idMeal}`)}
              >
                Get Recipe
              </button>
            </div>
          </div>
        </section>
      </div>
    </>
  );
};
