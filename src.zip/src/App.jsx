import { Route, Routes } from "react-router-dom";
import { Home } from "./components/Home";
import { Signup } from "./components/Signup";
import { Login } from "./components/Login";
import { ForgotPassword } from "./components/ForgotPassword";
import { SearchResult } from "./components/SearchResult";
import { SavedRecipes } from "./components/SavedRecipes";
import { ProtectedRoute } from "../../habitly/src/components/ProtectedRoute";
import { useState } from "react";
import { FullRecipe } from "./components/FullRecipe";
function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(() => {
    return Boolean(localStorage.getItem("recipeBoxCurrentUser"));
  });

  return (
    <>
      <Routes>
        <Route path="/" element={<Home />}></Route>
        <Route
          path="/signup"
          element={<Signup setIsLoggedIn={setIsLoggedIn} />}
        />
        <Route
          path="/login"
          element={<Login setIsLoggedIn={setIsLoggedIn} />}
        />
        <Route
          path="/forgot"
          element={<ForgotPassword setIsLoggedIn={setIsLoggedIn} />}
        />
        <Route
          path="/search"
          element={
            <SearchResult
              isLoggedIn={isLoggedIn}
              setIsLoggedIn={setIsLoggedIn}
            />
          }
        />
        <Route
          path="/myrecipes"
          element={
            <ProtectedRoute isLoggedIn={isLoggedIn}>
              <SavedRecipes
                isLoggedIn={isLoggedIn}
                setIsLoggedIn={setIsLoggedIn}
              />
            </ProtectedRoute>
          }
        />
        <Route path="/recipe/:id" element={<FullRecipe />} />
      </Routes>
    </>
  );
}

export default App;
